"""API package initialization"""
